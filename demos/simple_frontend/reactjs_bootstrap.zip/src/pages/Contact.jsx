import React from 'react';
import { Container, Form, Button } from 'react-bootstrap';

import { useFormik } from 'formik';
import { contactusSchemas } from '../schemas';

import axios from 'axios';
import configData from "../config/config.json";

import { toast } from 'react-toastify';

const initialValues = { name: "", email: "", message: "" }

const Contact = () => {
  const formikFormHandler = useFormik({
    initialValues,
    validationSchema: contactusSchemas,
    onSubmit:(values, action)=>{
      axios.post(`${configData.baseUrlAPI}/contact-us`, values)
      .then((response) => {
        toast.success("Thank you for reaching out! Your message has been successfully sent. We will get back to you soon.");
        action.resetForm();
      })
      .finally(() => {
        action.setSubmitting(false);
      });
    }
  });
  
  const {values, errors, touched, handleBlur, handleChange, handleSubmit, isValid, isSubmitting} = formikFormHandler;

  return (
    <Container className="py-5">
      <h1 className="mb-4">Contact Us</h1>
      <p>If you have any questions or feedback, feel free to reach out using the form below.</p>
      
      <Form onSubmit={handleSubmit}>
        <Form.Group className="mb-3" controlId="formName">
          <Form.Label>Your Name</Form.Label>
          <Form.Control type="text" name="name" placeholder="Enter your name" value={values.name} onChange={handleChange} onBlur={handleBlur} isInvalid={touched.name && !!errors.name} />
          {errors.name && touched.name ? <p className='text-danger'>{errors.name}</p> : null}
        </Form.Group>

        <Form.Group className="mb-3" controlId="formEmail">
          <Form.Label>Email address</Form.Label>
          <Form.Control type="email" name="email" placeholder="Enter your email" value={values.email} onChange={handleChange} onBlur={handleBlur} isInvalid={touched.email && !!errors.email} />
          {errors.email && touched.email ? <p className='text-danger'>{errors.email}</p> : null}
        </Form.Group>

        <Form.Group className="mb-3" controlId="formMessage">
          <Form.Label>Message</Form.Label>
          <Form.Control as="textarea" name="message" rows={4} placeholder="Type your message here..." value={values.message} onChange={handleChange} onBlur={handleBlur} isInvalid={touched.message && !!errors.message} />
          {errors.message && touched.message ? <p className='text-danger'>{errors.message}</p> : null}
        </Form.Group>

        <Button variant="primary" type="submit" disabled={!isValid || isSubmitting}>
          Submit
        </Button>
      </Form>
    </Container>
  );
};

export default Contact;
