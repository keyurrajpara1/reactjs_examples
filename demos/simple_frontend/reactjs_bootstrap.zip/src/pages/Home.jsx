import {
  Container,
  Button,
  Row,
  Col,
  Card
} from 'react-bootstrap';

const Home = () => {
  return (
    <>
      {/* Page Content */}
      <Container className="my-5 px-4 px-lg-5">
        {/* Heading Row */}
        <Row className="gx-4 gx-lg-5 align-items-center my-5">
          <Col lg={7}>
            <img
              className="img-fluid rounded mb-4 mb-lg-0"
              src="https://dummyimage.com/900x400/dee2e6/6c757d.jpg"
              alt=""
            />
          </Col>
          <Col lg={5}>
            <h1 className="font-weight-light">Business Name or Tagline</h1>
            <p>
              This is a template that is great for small businesses. It doesn't have too much fancy flare to it,
              but it makes great use of the standard Bootstrap core components.
              Feel free to use this template for any project you want!
            </p>
            <Button variant="primary">Call to Action!</Button>
          </Col>
        </Row>

        {/* Call to Action */}
        <Card className="text-white bg-secondary text-center my-5 py-4">
          <Card.Body>
            This call to action card is a great place to showcase some important information or display a clever tagline!
          </Card.Body>
        </Card>

        {/* Content Row */}
        <Row className="gx-4 gx-lg-5">
          {["Card One", "Card Two", "Card Three"].map((title, i) => (
            <Col md={4} className="mb-5" key={i}>
              <Card className="h-100">
                <Card.Body>
                  <Card.Title>{title}</Card.Title>
                  <Card.Text>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem magni quas ex numquam, maxime minus quam molestias corporis quod, ea minima accusamus.
                  </Card.Text>
                </Card.Body>
                <Card.Footer>
                  <Button variant="primary" size="sm">More Info</Button>
                </Card.Footer>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
    </>
  )
}

export default Home;