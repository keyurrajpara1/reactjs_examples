import React from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';

import { useFormik } from 'formik';
import { signupSchemas } from '../schemas';

import axios from 'axios';
import configData from "../config/config.json";

import { toast } from 'react-toastify';

const initialValues = { first_name: "", last_name: "", email: "", phone_number: "", password: "", password_confirmation: "" }

const Signup = () => {
  const formikFormHandler = useFormik({
    initialValues,
    validationSchema: signupSchemas,
    /* onSubmit:(values, action)=>{
      console.log(values);
      axios.post(`${configData.baseUrlAPI}/signup`, values)
      .then((response) => {
        toast.success("Your account has been successfully created! Welcome aboard. Please check your email for further instructions.");
        action.resetForm();
      })
      .finally(() => {
        action.setSubmitting(false);
      });
    } */
    onSubmit: async (values, actions) => {
      try {
        const response = await axios.post(`${configData.baseUrlAPI}/signup`, values);
        
        toast.success("Your account has been successfully created! Welcome aboard.");
        actions.resetForm();
      }
      catch (error) {
        // 💥 Handle Laravel validation errors
        if (error.response && error.response.data && error.response.data.errors) {
          const serverErrors = error.response.data.errors;
    
          // Convert Laravel error arrays into Formik-friendly strings
          const formattedErrors = {};
          for (const key in serverErrors) {
            formattedErrors[key] = serverErrors[key][0]; // Just take first error
          }
    
          actions.setErrors(formattedErrors); // 💥 Inject errors into Formik
        }
      }
      finally {
        actions.setSubmitting(false);
      }
    }    
  });
  
  const {values, errors, touched, handleBlur, handleChange, handleSubmit, isValid, isSubmitting} = formikFormHandler;
  
  return (
    <Container fluid className="d-flex justify-content-center align-items-center py-5">
      <Row className="w-50">
        <Col xs={12} md={6} lg={4} className="mx-auto">
          <div className="text-center mb-4">
            <h2>Sign Up</h2>
            <p>Create your account</p>
          </div>
          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-3" controlId="first_name">
              <Form.Label>First Name</Form.Label>
              <Form.Control type="text" name="first_name" placeholder="First Name" value={values.first_name} onChange={handleChange} onBlur={handleBlur} isInvalid={touched.first_name && !!errors.first_name} />
              {errors.first_name && touched.first_name ? <p className='text-danger'>{errors.first_name}</p> : null}
            </Form.Group>

            <Form.Group className="mb-3" controlId="last_name">
              <Form.Label>Last Name</Form.Label>
              <Form.Control type="text" name="last_name" placeholder="Last Name" value={values.last_name} onChange={handleChange} onBlur={handleBlur} isInvalid={touched.last_name && !!errors.last_name} />
              {errors.last_name && touched.last_name ? <p className='text-danger'>{errors.last_name}</p> : null}
            </Form.Group>

            <Form.Group className="mb-3" controlId="email">
              <Form.Label>Email</Form.Label>
              <Form.Control type="text" name="email" placeholder="Email" value={values.email} onChange={handleChange} onBlur={handleBlur} isInvalid={touched.email && !!errors.email} />
              {errors.email && touched.email ? <p className='text-danger'>{errors.email}</p> : null}
            </Form.Group>

            <Form.Group className="mb-3" controlId="phone_number">
              <Form.Label>Phone Number</Form.Label>
              <Form.Control type="text" name="phone_number" placeholder="Phone Number" value={values.phone_number} onChange={handleChange} onBlur={handleBlur} isInvalid={touched.phone_number && !!errors.phone_number} />
              {errors.phone_number && touched.phone_number ? <p className='text-danger'>{errors.phone_number}</p> : null}
            </Form.Group>

            <Form.Group className="mb-3" controlId="password">
              <Form.Label>Password</Form.Label>
              <Form.Control type="password" name="password" placeholder="Password" value={values.password} onChange={handleChange} onBlur={handleBlur} isInvalid={touched.password && !!errors.password} />
              {errors.password && touched.password ? <p className='text-danger'>{errors.password}</p> : null}
            </Form.Group>
            
            <Form.Group className="mb-3" controlId="password_confirmation">
              <Form.Label>Confirm Password</Form.Label>
              <Form.Control type="password" name="password_confirmation" placeholder="Confirm Password" value={values.password_confirmation} onChange={handleChange} onBlur={handleBlur} isInvalid={touched.password_confirmation && !!errors.password_confirmation} />
              {errors.password_confirmation && touched.password_confirmation ? <p className='text-danger'>{errors.password_confirmation}</p> : null}
            </Form.Group>

            {/* Submit Button */}
            <Button variant="primary" type="submit" disabled={!isValid || isSubmitting}>
              Sign Up
            </Button>
          </Form>
        </Col>
      </Row>
    </Container>
  );
};

export default Signup;
