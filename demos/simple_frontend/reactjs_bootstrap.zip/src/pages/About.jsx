import React from 'react';
import { Container } from 'react-bootstrap';

const About = () => {
  return (
    <Container className="py-5">
      <h1 className="mb-4">About Us</h1>
      <p>
        Welcome to our website! We're a team of passionate developers building useful tools and resources to help others learn and grow.
      </p>
      <p>
        This is a demo About page using React and React-Bootstrap. You can customize this content however you like.
      </p>
    </Container>
  );
};

export default About;
