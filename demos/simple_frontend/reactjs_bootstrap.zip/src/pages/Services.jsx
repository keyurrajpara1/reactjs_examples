import React from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';

const Services = () => {
  const services = [
    {
      title: 'Web Development',
      description: 'We create fast, responsive, and scalable websites tailored to your business needs.',
    },
    {
      title: 'Mobile Apps',
      description: 'Custom mobile app solutions for iOS and Android to boost user engagement.',
    },
    {
      title: 'SEO Optimization',
      description: 'Improve your website visibility and attract more traffic through effective SEO strategies.',
    },
  ];

  return (
    <Container className="py-5">
      <h1 className="mb-4">Our Services</h1>
      <Row>
        {services.map((service, index) => (
          <Col md={4} className="mb-4" key={index}>
            <Card className="h-100 shadow-sm">
              <Card.Body>
                <Card.Title>{service.title}</Card.Title>
                <Card.Text>{service.description}</Card.Text>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default Services;
