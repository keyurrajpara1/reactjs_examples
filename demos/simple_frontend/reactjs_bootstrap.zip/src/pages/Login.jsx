import React from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';

import { useFormik } from 'formik';
import { loginSchemas } from '../schemas';

import axios from 'axios';
import configData from "../config/config.json";

import { toast } from 'react-toastify';

const initialValues = { email: "", password: "" }

const Login = () => {
  const formikFormHandler = useFormik({
    initialValues,
    validationSchema: loginSchemas,
    /* onSubmit:(values, action)=>{
      console.log(values);
      axios.post(`${configData.baseUrlAPI}/signup`, values)
      .then((response) => {
        toast.success("Your account has been successfully created! Welcome aboard. Please check your email for further instructions.");
        action.resetForm();
      })
      .finally(() => {
        action.setSubmitting(false);
      });
    } */
    onSubmit: async (values, actions) => {
      try {
        const response = await axios.post(`${configData.baseUrlAPI}/signup`, values);
        
        toast.success("Your account has been successfully created! Welcome aboard.");
        actions.resetForm();
      }
      catch (error) {
        // 💥 Handle Laravel validation errors
        if (error.response && error.response.data && error.response.data.errors) {
          const serverErrors = error.response.data.errors;
    
          // Convert Laravel error arrays into Formik-friendly strings
          const formattedErrors = {};
          for (const key in serverErrors) {
            formattedErrors[key] = serverErrors[key][0]; // Just take first error
          }
    
          actions.setErrors(formattedErrors); // 💥 Inject errors into Formik
        }
      }
      finally {
        actions.setSubmitting(false);
      }
    }    
  });
  
  const {values, errors, touched, handleBlur, handleChange, handleSubmit, isValid, isSubmitting} = formikFormHandler;
  
  return (
    <Container fluid className="d-flex justify-content-center align-items-center py-5">
      <Row className="w-50">
        <Col xs={12} md={6} lg={4} className="mx-auto">
          <div className="text-center mb-4">
            <h2>Login</h2>
            {/* <p>Create your account</p> */}
          </div>
          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-3" controlId="email">
              <Form.Label>Email</Form.Label>
              <Form.Control type="text" name="email" placeholder="Email" value={values.email} onChange={handleChange} onBlur={handleBlur} isInvalid={touched.email && !!errors.email} />
              {errors.email && touched.email ? <p className='text-danger'>{errors.email}</p> : null}
            </Form.Group>

            <Form.Group className="mb-3" controlId="password">
              <Form.Label>Password</Form.Label>
              <Form.Control type="password" name="password" placeholder="Password" value={values.password} onChange={handleChange} onBlur={handleBlur} isInvalid={touched.password && !!errors.password} />
              {errors.password && touched.password ? <p className='text-danger'>{errors.password}</p> : null}
            </Form.Group>

            {/* Submit Button */}
            <Button variant="primary" type="submit" block>
              Login
            </Button>
          </Form>
        </Col>
      </Row>
    </Container>
  );
};

export default Login;
