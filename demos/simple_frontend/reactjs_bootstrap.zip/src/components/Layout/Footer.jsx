import {
  Container
} from 'react-bootstrap';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <>
      {/* Footer */}
      <footer className="py-5 bg-dark">
        <Container>
          <p className="m-0 text-center text-white">Copyright &copy; Keyur Lorem Ipsum {currentYear}</p>
        </Container>
      </footer>
    </>
  )
}

export default Footer;