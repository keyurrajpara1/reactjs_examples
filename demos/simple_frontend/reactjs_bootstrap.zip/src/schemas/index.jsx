import * as Yup from 'yup';
export const contactusSchemas = Yup.object({
    name: Yup.string().min(2, "Name must be at least 2 characters").max(25).required("Please enter your name"),
    email: Yup.string().email().required("Please enter your email"),
    message: Yup.string().min(10, "Message must be at least 10 characters").max(3000).required("Please enter your message"),
});

export const signupSchemas = Yup.object({
    first_name: Yup.string().min(2, "First name must be at least 2 characters").max(25).required("Please enter your first name"),
    last_name: Yup.string().min(2, "Last name must be at least 2 characters").max(25).required("Please enter your last name"),
    email: Yup.string().email().required("Please enter your email"),
    phone_number: Yup.string().required("Please enter your phone number"),
    password: Yup.string().min(6, "Password must be at least 6 characters").required("Please enter your password"),
    password_confirmation: Yup.string().required("Please confirm your password").oneOf([Yup.ref("password"), null], "Passwords must match"),
});

export const loginSchemas = Yup.object({
    email: Yup.string().email().required("Please enter your email"),
    password: Yup.string().min(6, "Password must be at least 6 characters").required("Please enter your password"),
});