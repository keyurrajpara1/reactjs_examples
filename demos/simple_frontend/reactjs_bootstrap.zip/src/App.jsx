import './App.css'

import 'bootstrap/dist/css/bootstrap.min.css';

import NavbarComponent from "./components/Layout/NavbarComponent";
import PageContent from "./components/PageContent";
import Footer from "./components/Layout/Footer";

function App() {
  return (
    <>
      <NavbarComponent />
      <PageContent />
      <Footer />
    </>
  )
}

export default App
