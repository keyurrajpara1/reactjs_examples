import { Route, Routes, Navigate } from "react-router";
import Home from './components/Home.jsx';
import About from './components/About.jsx';
import UserList from './components/UserList.jsx';
import UserDetails from './components/UserDetails.jsx';
import Login from './components/Login.jsx';
import College from './components/College.jsx';
import Student from './components/Student.jsx';
import Departments from './components/Departments.jsx';
import CollegeDetails from './components/CollegeDetails.jsx';
import PageNotFound from './components/PageNotFound.jsx';
import Navbar from './components/Navbar.jsx';
function App() {
    return (
        <>
            {/* <Navbar /> */}
            <Routes>
                <Route element={<Navbar />}>
                    <Route path="/" element={<Home />} />
                    <Route path="/about" element={<About />} />
                    <Route path='in'>
                        <Route path='/in/user'>
                            <Route path="/in/user/login" element={<Login />} />
                        </Route>
                    </Route>
                    
                    <Route path="/users/list?" element={<UserList />} />
                    {/* <Route path="/users" element={<UserList />} />
                    <Route path="/users/list" element={<UserList />} /> */}

                    <Route path='/users/:id/:name?' element={<UserDetails />} />
                    {/* <Route path='/users/:id' element={<UserDetails />} />
                    <Route path='/users/:id/:name' element={<UserDetails />} /> */}
                </Route>
                <Route path="/college" element={<College />}>
                    <Route index element={<Student />} />
                    <Route path="departments" element={<Departments />} />
                    <Route path="collegedetails" element={<CollegeDetails />} />
                </Route>
                {/* <Route path="/*" element={<PageNotFound />} /> */}
                <Route path="/*" element={<Navigate to="/" />} />
            </Routes>
        </>
    )
}
export default App