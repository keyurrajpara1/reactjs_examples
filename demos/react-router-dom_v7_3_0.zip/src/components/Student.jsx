function Student() {
    return (
        <>
            <h1>Student Page</h1>
        </>
    )
}
export default Student