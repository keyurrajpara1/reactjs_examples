function Departments() {
    return (
        <>
            <h1>Departments Page</h1>
        </>
    )
}
export default Departments