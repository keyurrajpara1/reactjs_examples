function CollegeDetails() {
    return (
        <>
            <h1>CollegeDetails Page</h1>
        </>
    )
}
export default CollegeDetails