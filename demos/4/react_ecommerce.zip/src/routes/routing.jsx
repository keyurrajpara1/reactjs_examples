import React, { useEffect } from "react";
import Dashboard from '@/pages/admin/Dashboard';
import Profile from '@/pages/admin/Profile';
import { Routes, Route, useLocation, Navigate } from "react-router-dom";
import MasterLayout from '@/layouts/admin/MasterLayout';
import Home from '@/pages/frontend/Home';
import Register from '@/pages/frontend/auth/Register';
import Login from '@/pages/frontend/auth/Login';
import ProtectedRoute from '@/routes/ProtectedRoute';

const Routing = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <>
      <Routes>
        {/* Frontend website routes */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={ localStorage.getItem('auth_token') ? <Navigate to="/" /> : <Login /> } />
        <Route path="/register" element={ localStorage.getItem('auth_token') ? <Navigate to="/" /> : <Register /> } />

        {/* Backend website routes */}
        <Route path="admin" element={<ProtectedRoute><MasterLayout /></ProtectedRoute>}>
          <Route index element={<Navigate to="dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="profile" element={<Profile />} />
        </Route>

        {/* Catch-all route to redirect */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
};

export default Routing;
