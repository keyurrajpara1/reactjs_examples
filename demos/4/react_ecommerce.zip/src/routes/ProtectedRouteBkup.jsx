import React, { useState, useEffect } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import axios from "axios";
import swal from "sweetalert";
const ProtectedRouteBkup = ({ children }) => {
  const navigate = useNavigate();

  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    
    axios.get('/user').then((res) => {
      if(res.status == 200){
        setIsAuthenticated(true);
      }
      setLoading(false);
    });

    return () => {
      setIsAuthenticated(false);
    };

  }, []);

  axios.interceptors.response.use(undefined, function axiosRetryInterceptor(err){
    if(err.response.status == 401){
      swal("Unauthorized", err.response.data.message, "warning");
      navigate('/');
    }
    return Promise.reject(err);
  });

  if(loading){
    return (
      <><h1>Loading...</h1></>
    )
  }

  // const isAuthenticated = !!localStorage.getItem("auth_token"); // Not secured way

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return children;
};

export default ProtectedRouteBkup;
