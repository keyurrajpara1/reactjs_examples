<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Laravel React Setup</title>
</head>
<body>
    <div id="app"></div>
    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</body>
</html><?php /**PATH D:\xampp_php_8_2_12\htdocs\practice\laravel_react\resources\views/welcome.blade.php ENDPATH**/ ?>