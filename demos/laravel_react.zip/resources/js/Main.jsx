import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router';
import App from './App.jsx';
const Main = () => {
  return (
    <>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </>
  )
}
if(document.getElementById('app')){
  createRoot(document.getElementById('app')).render(<Main />)
}