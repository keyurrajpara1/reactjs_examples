import Navbar from '@/pages/frontend/Navbar';
const Home = () => {
  return (
    <>
      <Navbar />
      Home Page
    </>
  )
}

export default Home