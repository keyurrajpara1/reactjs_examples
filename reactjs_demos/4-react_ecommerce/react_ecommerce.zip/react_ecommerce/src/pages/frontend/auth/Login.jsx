import { Link, useNavigate } from "react-router-dom";
import Navbar from '@/pages/frontend/Navbar';

import { useFormik } from 'formik';
import { loginSchemas } from '@/schemas';

import axios from 'axios';

import { toast } from 'react-toastify';
import swal from 'sweetalert';

const initialValues = { email: "", password: "" }

const Login = () => {
  const navigate = useNavigate();

  const formikFormHandler = useFormik({
    initialValues,
    validationSchema: loginSchemas,
    onSubmit: async (values, actions) => {
      try {
        const response = await axios.post(`/login`, values);
        localStorage.setItem('auth_token', response.data.token);
        localStorage.setItem('auth_name', response.data.user.first_name);
        toast.success("Login successful. Welcome back!");
        swal("Login successful. Welcome back!");
        actions.resetForm();
        if(response.data.role == 'admin'){
          navigate('/admin/dashboard');
        }
        else{
          navigate('/');
        }
      }
      catch (error) {
        // 💥 Handle Laravel validation errors
        if (error.response && error.response.data && error.response.data.errors) {
          const serverErrors = error.response.data.errors;
    
          // Convert Laravel error arrays into Formik-friendly strings
          const formattedErrors = {};
          for (const key in serverErrors) {
            formattedErrors[key] = serverErrors[key][0]; // Just take first error
          }
    
          actions.setErrors(formattedErrors); // 💥 Inject errors into Formik
        }
      }
      finally {
        actions.setSubmitting(false);
      }
    }    
  });

  const {values, errors, touched, handleBlur, handleChange, handleSubmit, isValid, isSubmitting} = formikFormHandler;

  return (
    <>
      <Navbar />
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">

            <div className="d-flex justify-content-center py-4">
              <Link to="index.html" className="logo d-flex align-items-center w-auto">
                {/* <img src="assets/img/logo.png" alt=""> */}
                {/* <span className="d-none d-lg-block">NiceAdmin</span> */}
              </Link>
            </div>

            <div className="card mb-3">

              <div className="card-body">

                <div className="pt-4 pb-2">
                  <h5 className="card-title text-center pb-0 fs-4">Login to Your Account</h5>
                  <p className="text-center small">Enter your username &amp; password to login</p>
                </div>

                <form className="row g-3 needs-validation" onSubmit={handleSubmit}>
                  <div className="col-12">
                    <label htmlFor="email" className="form-label">Email</label>
                    <input type="email" name="email" className={`form-control ${touched.first_name && errors.first_name ? 'is-invalid' : ''}`} id="email" value={values.email} onChange={handleChange} onBlur={handleBlur} />
                    {errors.email && touched.email ? <div className='text-danger'>{errors.email}</div> : null}
                  </div>

                  <div className="col-12">
                    <label htmlFor="password" className="form-label">Password</label>
                    <input type="password" name="password" className={`form-control ${touched.first_name && errors.first_name ? 'is-invalid' : ''}`} id="password" value={values.password} onChange={handleChange} onBlur={handleBlur} />
                    {errors.password && touched.password ? <div className='text-danger'>{errors.password}</div> : null}
                  </div>

                  {/* <div className="col-12">
                    <div className="form-check">
                      <input className="form-check-input" type="checkbox" name="remember" value="true" id="rememberMe" />
                      <label className="form-check-label" for="rememberMe">Remember me</label>
                    </div>
                  </div> */}
                  
                  <div className="col-12">
                    <button className="btn btn-primary w-100" type="submit" disabled={!isValid || isSubmitting}>Login</button>
                  </div>
                  <div className="col-12">
                    <p className="small mb-0">Don't have account? <Link to="/register">Create an account</Link></p>
                  </div>
                </form>

              </div>
            </div>

            <div className="credits">
              {/* Designed by <Link to="https://bootstrapmade.com/">BootstrapMade</Link> */}
            </div>

          </div>
        </div>
      </div>
    </>
  )
}

export default Login