import { useFormik } from 'formik';
// import { loginSchemas } from '@/schemas';

import {Link} from 'react-router';

import axios from 'axios';

import { addCategorySchemas } from '@/schemas';

import { toast } from 'react-toastify';
import swal from 'sweetalert';

const initialValues = { slug: "", name: "", description: "", status: 0, meta_title: "", meta_keywords: "", meta_description: "" };

const AddProduct = () => {
  return (
    <>
      <div className='container-fluid px-4'>
        <div className='card mt-4'>
          <div className='card-header'>
            <h4>Add Product
              <Link to="/admin/view-products" className='btn btn-primary btn-sm float-end'>View Products</Link>
            </h4>
          </div>
          {/* <div class>

          </div> */}
        </div>
      </div>
    </>
  )
}

export default AddProduct