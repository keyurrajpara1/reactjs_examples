import { useFormik } from 'formik';
// import { loginSchemas } from '@/schemas';

import axios from 'axios';

import { addCategorySchemas } from '@/schemas';

import { toast } from 'react-toastify';
import swal from 'sweetalert';

const initialValues = { slug: "", name: "", description: "", status: 0, meta_title: "", meta_keywords: "", meta_description: "" };

const ViewProducts = () => {
  return (
    <>
      ViewProducts
    </>
  )
}

export default ViewProducts