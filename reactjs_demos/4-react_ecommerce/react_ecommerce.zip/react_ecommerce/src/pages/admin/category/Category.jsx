import { useFormik } from 'formik';
// import { loginSchemas } from '@/schemas';

import axios from 'axios';

import { addCategorySchemas } from '@/schemas';

import { toast } from 'react-toastify';
import swal from 'sweetalert';

const initialValues = { slug: "", name: "", description: "", status: 0, meta_title: "", meta_keywords: "", meta_description: "" };

const Category = () => {
  // let addCategorySchemas = {};
  const formikFormHandler = useFormik({
    initialValues,
    validationSchema: addCategorySchemas,
    onSubmit: async (values, actions) => {
      console.log(values);
      try {
        const response = await axios.post(`/categories`, values);
        toast.success("Added successfully");
        swal("Added successfully");
        actions.resetForm();

        /* axios.post(`/categories`, data).then(res => {
          if(res.data.status === 200){
            // swal("Success", res.data.message, "success");
            // document.getElementById('category_form').reset();
          }
          else if(res.data.status === 400){
            // setCategory({...categoryInput, error_list:res.data.errors});
          }
        }); */

        actions.resetForm();
      }
      catch (error) {
        // 💥 Handle Laravel validation errors
        if (error.response && error.response.data && error.response.data.errors) {
          const serverErrors = error.response.data.errors;
    
          // Convert Laravel error arrays into Formik-friendly strings
          const formattedErrors = {};
          for (const key in serverErrors) {
            formattedErrors[key] = serverErrors[key][0]; // Just take first error
          }
    
          actions.setErrors(formattedErrors); // 💥 Inject errors into Formik
        }
      }
      finally {
        actions.setSubmitting(false);
      }
    }    
  });

  const {values, errors, touched, handleBlur, handleChange, handleSubmit, isValid, isSubmitting} = formikFormHandler;

  return (
    <>
      <div className="container-fluid px-4">
        <h1 className="mt-4">Add Category</h1>
        <form onSubmit={handleSubmit} id="category_form">
          <ul className="nav nav-tabs" id="myTab" role="tablist">
            <li className="nav-item" role="presentation">
              <button className="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">Home</button>
            </li>
            <li className="nav-item" role="presentation">
              <button className="nav-link" id="seo-tags-tab" data-bs-toggle="tab" data-bs-target="#seo-tags" type="button" role="tab" aria-controls="seo-tags" aria-selected="false">SEO Tags</button>
            </li>
          </ul>
          <div className="tab-content" id="myTabContent">
            <div className="tab-pane card-body border fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabIndex="0">
              <div className="form-group mb-3">
                <label>Slug</label>
                <input type="text" name="slug" className={`form-control ${touched.slug && errors.slug ? 'is-invalid' : ''}`} value={values.slug} onChange={handleChange} onBlur={handleBlur} />
                {errors.slug && touched.slug ? <div className='text-danger'>{errors.slug}</div> : null}
              </div>
              <div className="form-group mb-3">
                <label>Name</label>
                <input type="text" name="name" className={`form-control ${touched.name && errors.name ? 'is-invalid' : ''}`} value={values.name} onChange={handleChange} onBlur={handleBlur} />
                {errors.name && touched.name ? <div className='text-danger'>{errors.name}</div> : null}
              </div>
              <div className="form-group mb-3">
                <label>Description</label>
                <textarea name="description" className={`form-control ${touched.description && errors.description ? 'is-invalid' : ''}`} value={values.description} onChange={handleChange} onBlur={handleBlur} />
                {errors.description && touched.description ? <div className="text-danger">{errors.description}</div> : null}
              </div>

              <div className="form-group mb-3">
                <label>Status</label>
                <div className="form-check">
                  <input
                    type="checkbox"
                    name="status"
                    className="form-check-input"
                    checked={values.status === 1}
                    onChange={(e) => formikFormHandler.setFieldValue("status", e.target.checked ? 1 : 0)}
                  />
                  Status (0 = shown / 1 = hidden)
                </div>
              </div>

            </div>
            <div className="tab-pane card-body border fade" id="seo-tags" role="tabpanel" aria-labelledby="seo-tags-tab" tabIndex="0">
              <div className="form-group mb-3">
                <label>Meta Title</label>
                <input type="text" name="meta_title" className={`form-control ${touched.meta_title && errors.meta_title ? 'is-invalid' : ''}`} value={values.meta_title} onChange={handleChange} onBlur={handleBlur} />
                {errors.meta_title && touched.meta_title ? <div className="text-danger">{errors.meta_title}</div> : null}
              </div>

              <div className="form-group mb-3">
                <label>Meta Keywords</label>
                <textarea name="meta_keywords" className={`form-control ${touched.meta_keywords && errors.meta_keywords ? 'is-invalid' : ''}`} value={values.meta_keywords} onChange={handleChange} onBlur={handleBlur} />
                {errors.meta_keywords && touched.meta_keywords ? <div className="text-danger">{errors.meta_keywords}</div> : null}
              </div>

              <div className="form-group mb-3">
                <label>Meta Description</label>
                <textarea name="meta_description" className={`form-control ${touched.meta_description && errors.meta_description ? 'is-invalid' : ''}`} value={values.meta_description} onChange={handleChange} onBlur={handleBlur} />
                {errors.meta_description && touched.meta_description ? <div className="text-danger">{errors.meta_description}</div> : null}
              </div>
            </div>
          </div>
          <button type="submit" className="btn btn-primary px-4 float-end">Submit</button>
        </form>
      </div>
    </>
  )
}

export default Category