import { useFormik } from 'formik';
import axios from 'axios';
import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom'; // assuming you're using React Router
import { addCategorySchemas } from '@/schemas';
import { toast } from 'react-toastify';
import swal from 'sweetalert';

const EditCategory = () => {
  const navigate = useNavigate();
  const { id } = useParams(); // fetch the category ID from URL
  const [loading, setLoading] = useState(true);

  const formik = useFormik({
    initialValues: { slug: '', name: '', description: '', status: 0, meta_title: '', meta_keywords: '', meta_description: '' },
    validationSchema: addCategorySchemas,
    enableReinitialize: true, // allow re-population of form
    onSubmit: async (values, actions) => {
      try {
        // console.log("values: ");
        // console.log(values);
        const res = await axios.put(`/categories/${id}`, values);
        toast.success("Updated successfully");
        swal("Updated successfully");
      } catch (error) {
        if (error.response?.data?.errors) {
          const formattedErrors = {};
          for (const key in error.response.data.errors) {
            formattedErrors[key] = error.response.data.errors[key][0];
          }
          actions.setErrors(formattedErrors);
        }
      } finally {
        actions.setSubmitting(false);
      }
    }
  });

  useEffect(() => {
    const fetchCategory = async () => {
      try {
        const res = await axios.get(`/categories/${id}`);
        // formik.setValues(res.data);
        if (res.data.status === 404) {
          toast.error("Category not found");
          swal("Category not found");
          navigate("/admin/view-category");
          return;
        }
        formik.setValues(res.data.category);
      } catch (error) {
        toast.error("Failed to fetch category");
      } finally {
        setLoading(false);
      }
    };

    fetchCategory();
  }, [id]);

  const { values, errors, touched, handleBlur, handleChange, handleSubmit, isSubmitting } = formik;

  if (loading) return <p>Loading...</p>;

  return (
    <div className="container-fluid px-4">
      <h1 className="mt-4">Edit Category</h1>
      <form onSubmit={handleSubmit}>
        {/* Same tab structure as your Add form, repeat inputs with formik binding */}
        {/* For brevity, re-use your original form JSX structure here */}
        {/* Just ensure values come from formik.values and handlers are bound */}
        <ul className="nav nav-tabs" id="myTab" role="tablist">
          <li className="nav-item" role="presentation">
            <button className="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">Home</button>
          </li>
          <li className="nav-item" role="presentation">
            <button className="nav-link" id="seo-tags-tab" data-bs-toggle="tab" data-bs-target="#seo-tags" type="button" role="tab" aria-controls="seo-tags" aria-selected="false">SEO Tags</button>
          </li>
        </ul>
        <div className="tab-content" id="myTabContent">
          <div className="tab-pane card-body border fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabIndex="0">
            <div className="form-group mb-3">
              <label>Slug</label>
              <input type="text" name="slug" className={`form-control ${touched.slug && errors.slug ? 'is-invalid' : ''}`} value={values.slug} onChange={handleChange} onBlur={handleBlur} />
              {errors.slug && touched.slug ? <div className='text-danger'>{errors.slug}</div> : null}
            </div>
            <div className="form-group mb-3">
              <label>Name</label>
              <input type="text" name="name" className={`form-control ${touched.name && errors.name ? 'is-invalid' : ''}`} value={values.name} onChange={handleChange} onBlur={handleBlur} />
              {errors.name && touched.name ? <div className='text-danger'>{errors.name}</div> : null}
            </div>
            <div className="form-group mb-3">
              <label>Description</label>
              <textarea name="description" className={`form-control ${touched.description && errors.description ? 'is-invalid' : ''}`} value={values.description} onChange={handleChange} onBlur={handleBlur} />
              {errors.description && touched.description ? <div className="text-danger">{errors.description}</div> : null}
            </div>

            <div className="form-group mb-3">
              <label>Status</label>
              <div className="form-check">
                <input
                  type="checkbox"
                  name="status"
                  className="form-check-input"
                  checked={values.status === 1}
                  onChange={(e) => formik.setFieldValue("status", e.target.checked ? 1 : 0)}
                />
                Status (0 = shown / 1 = hidden)
              </div>
            </div>

          </div>
          <div className="tab-pane card-body border fade" id="seo-tags" role="tabpanel" aria-labelledby="seo-tags-tab" tabIndex="0">
            <div className="form-group mb-3">
              <label>Meta Title</label>
              <input type="text" name="meta_title" className={`form-control ${touched.meta_title && errors.meta_title ? 'is-invalid' : ''}`} value={values.meta_title} onChange={handleChange} onBlur={handleBlur} />
              {errors.meta_title && touched.meta_title ? <div className="text-danger">{errors.meta_title}</div> : null}
            </div>

            <div className="form-group mb-3">
              <label>Meta Keywords</label>
              <textarea name="meta_keywords" className={`form-control ${touched.meta_keywords && errors.meta_keywords ? 'is-invalid' : ''}`} value={values.meta_keywords} onChange={handleChange} onBlur={handleBlur} />
              {errors.meta_keywords && touched.meta_keywords ? <div className="text-danger">{errors.meta_keywords}</div> : null}
            </div>

            <div className="form-group mb-3">
              <label>Meta Description</label>
              <textarea name="meta_description" className={`form-control ${touched.meta_description && errors.meta_description ? 'is-invalid' : ''}`} value={values.meta_description} onChange={handleChange} onBlur={handleBlur} />
              {errors.meta_description && touched.meta_description ? <div className="text-danger">{errors.meta_description}</div> : null}
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <button type="submit" className="btn btn-primary px-4 float-end" disabled={isSubmitting}>
          Update
        </button>
      </form>
    </div>
  );
};

export default EditCategory;