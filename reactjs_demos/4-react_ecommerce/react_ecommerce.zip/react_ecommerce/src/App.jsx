import { BrowserRouter } from "react-router-dom";
import Routing from "./routes/routing";
import { ToastContainer } from 'react-toastify';
import axios from "axios";
axios.defaults.baseURL = "http://127.0.0.1:8000/api";
axios.defaults.headers.post["Accept"] = "application/json";
axios.defaults.headers.post["Content-Type"] = "application/json";
// axios.defaults.withCredentials = true;
axios.interceptors.request.use(function (config){
  const token = localStorage.getItem('auth_token');
  config.headers.Authorization = token ? `Bearer ${token}` : '';
  return config;
});
function App() {
  return (
    <>
      <BrowserRouter>
        <Routing />
        <ToastContainer />
      </BrowserRouter>
    </>
  )
}

export default App
