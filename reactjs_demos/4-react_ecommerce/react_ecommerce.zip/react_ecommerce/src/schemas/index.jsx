import * as Yup from 'yup';
export const signupSchemas = Yup.object({
    first_name: Yup.string().min(2, "First name must be at least 2 characters").max(25).required("Please enter your first name"),
    last_name: Yup.string().min(2, "Last name must be at least 2 characters").max(25).required("Please enter your last name"),
    email: Yup.string().email().required("Please enter your email"),
    password: Yup.string().min(6, "Password must be at least 6 characters").required("Please enter your password"),
    password_confirmation: Yup.string().required("Please confirm your password").oneOf([Yup.ref("password"), null], "Passwords must match"),
});

export const loginSchemas = Yup.object({
    email: Yup.string().email().required("Please enter your email"),
    password: Yup.string().min(6, "Password must be at least 6 characters").required("Please enter your password"),
});

export const addCategorySchemas = Yup.object({
  meta_title: Yup.string()
    .max(60, "Meta title can't be more than 60 characters")
    .required("Meta title is required"),
    
  meta_keywords: Yup.string()
    .max(255, "Meta keywords can't be more than 255 characters")
    .required("Meta keywords are required"),
    
  meta_description: Yup.string()
    .max(160, "Meta description can't be more than 160 characters")
    .required("Meta description is required"),
    
  slug: Yup.string()
    .matches(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Slug must be URL-friendly (lowercase, hyphens only)")
    .required("Slug is required"),
    
  name: Yup.string()
    .max(100, "Name can't be more than 100 characters")
    .required("Name is required"),
    
  description: Yup.string()
    .required("Description is required"),
    
  status: Yup.boolean()
    .required("Status is required"),
});
