import React, { useState, useEffect } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import axios from "axios";
import swal from "sweetalert";

const ProtectedRoute = ({ children }) => {
  const navigate = useNavigate();

  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Set up the axios interceptor inside the useEffect hook
    const axiosInterceptor = axios.interceptors.response.use(
      (response) => response,
      (err) => {
        if (err.response && err.response.status === 401) {
          swal("Unauthorized", err.response.data.message, "warning");
          navigate('/');
        }
        return Promise.reject(err);
      }
    );

    axios.interceptors.response.use(function (response){
      return response;
    }, function(error){
      if(error.response.status===403){
        swal("Forbidden", error.response.data.message, "Warning");
        navigate('/403');
      }
      else if(error.response.status===404){
        swal("404 Error", "Url/Page not found", "Warning");
        navigate('/404');
      }
      return Promise.reject(error);
    });

    // Check authentication status
    axios.get('/user').then((res) => {
      if (res.status === 200) {
        setIsAuthenticated(true);
      }
      setLoading(false);
    });

    // Cleanup interceptor when the component unmounts
    return () => {
      axios.interceptors.response.eject(axiosInterceptor);
    };
  }, [navigate]);

  if (loading) {
    return <h1>Loading...</h1>;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return children;
};

export default ProtectedRoute;
