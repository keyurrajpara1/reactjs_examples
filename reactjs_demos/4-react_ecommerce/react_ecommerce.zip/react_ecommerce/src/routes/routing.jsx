import React, { useEffect } from "react";
import Dashboard from '@/pages/admin/Dashboard';
import Profile from '@/pages/admin/Profile';
import Category from '@/pages/admin/category/Category';
import ViewCategory from '@/pages/admin/category/ViewCategory';
import EditCategory from '@/pages/admin/category/EditCategory';
import { Routes, Route, useLocation, Navigate } from "react-router-dom";
import MasterLayout from '@/layouts/admin/MasterLayout';
import Home from '@/pages/frontend/Home';
import Register from '@/pages/frontend/auth/Register';
import Login from '@/pages/frontend/auth/Login';
import ProtectedRoute from '@/routes/ProtectedRoute';

import Page403 from '@/pages/errors/Page403';
import Page404 from '@/pages/errors/Page404';

import AddProduct from '@/pages/admin/product/AddProduct';
import ViewProducts from '@/pages/admin/product/ViewProducts';

const Routing = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <>
      <Routes>
        {/* Frontend website routes */}
        <Route path="/403" element={<Page403 />} />
        <Route path="/404" element={<Page404 />} />
        <Route path="/" element={<Home />} />
        <Route path="/login" element={ localStorage.getItem('auth_token') ? <Navigate to="/" /> : <Login /> } />
        <Route path="/register" element={ localStorage.getItem('auth_token') ? <Navigate to="/" /> : <Register /> } />

        {/* Backend website routes */}
        <Route path="admin" element={<ProtectedRoute><MasterLayout /></ProtectedRoute>}>
          <Route index element={<Navigate to="dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="profile" element={<Profile />} />
          <Route path="add-category" element={<Category />} />
          <Route path="view-category" element={<ViewCategory />} />
          <Route path="edit-category/:id" element={<EditCategory />} />
          <Route path="add-product" element={<AddProduct />} />
          <Route path="view-products" element={<ViewProducts />} />
        </Route>

        {/* Catch-all route to redirect */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
};

export default Routing;
