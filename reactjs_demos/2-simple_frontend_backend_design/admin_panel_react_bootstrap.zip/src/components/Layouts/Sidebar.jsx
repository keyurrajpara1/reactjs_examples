import React, { useState, useEffect } from 'react';
const Sidebar = () => {
    useEffect(() => {
        // Check if the sidebar should be toggled on page load (from localStorage)
        if (localStorage.getItem('sb|sidebar-toggle') === 'true') {
            document.body.classList.add('sb-sidenav-toggled');
        }

        const sidebarToggle = document.querySelector('#sidebarToggle');
        if (sidebarToggle) {
            const toggleSidebar = (event) => {
            event.preventDefault();
            document.body.classList.toggle('sb-sidenav-toggled');
            localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
            };

            sidebarToggle.addEventListener('click', toggleSidebar);

            // Cleanup the event listener when the component unmounts
            return () => {
            sidebarToggle.removeEventListener('click', toggleSidebar);
            };
        }
    }, []); // Empty dependency array means this runs once on mount
    return (
        <>
            {/* Sidebar */}
            <div className="border-end bg-white" id="sidebar-wrapper">
                <div className="sidebar-heading border-bottom bg-light">Keyur Lorem ipsum</div>
                <div className="list-group list-group-flush">
                    <a className="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Dashboard</a>
                    <a className="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Shortcuts</a>
                    <a className="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Overview</a>
                    <a className="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Events</a>
                    <a className="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Profile</a>
                    <a className="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Status</a>
                </div>
            </div>
        </>
    )
}

export default Sidebar