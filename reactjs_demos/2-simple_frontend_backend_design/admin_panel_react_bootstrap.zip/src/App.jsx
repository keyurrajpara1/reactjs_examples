import { useLocation, useNavigate } from 'react-router-dom';
import Sidebar from './components/Layouts/Sidebar';
import HeaderNavbar from './components/Layouts/HeaderNavbar';
import PageContent from './components/PageContent';

function App() {
  const location = useLocation();
  const navigate = useNavigate();
  
  const isLoggedIn = localStorage.getItem('auth') === 'true';
  const isLoginPage = location.pathname === '/login';

  // Redirect to login if not logged in
  if (!isLoggedIn && !isLoginPage) {
    navigate('/login');
  }

  return (
    <>
      {/* Conditionally render Sidebar and HeaderNavbar */}
      {!isLoginPage && isLoggedIn && (
        <div className="d-flex" id="wrapper">
          <Sidebar />

          {/* Page content wrapper */}
          <div id="page-content-wrapper">
            <HeaderNavbar />
            <div className="container-fluid">
              <PageContent />
            </div>
          </div>
        </div>
      )}

      {/* Render Login Page when not logged in */}
      {isLoginPage && <PageContent />}
    </>
  );
}

export default App;
