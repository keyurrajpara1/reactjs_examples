const Dashboard = () => {
  return (
    <>
        <h1 className="mt-4">Dashboard</h1>
    </>
  )
}

export default Dashboard